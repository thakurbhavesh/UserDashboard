<?php include 'includes/header.php'; ?>
<div class="mb-3">
    <h3 class="fw-bold fs-4 mb-3">User Material</h3>
    <div class="container-fluid mt-4">
        <ul class="nav nav-tabs" id="myTab" role="tablist">
            <li class="nav-item" role="presentation">
                <a class="nav-link active" id="home-tab" data-bs-toggle="tab" href="#home" role="tab"
                    aria-controls="home" aria-selected="true">Tab 1</a>
            </li>
            <li class="nav-item" role="presentation">
                <a class="nav-link" id="profile-tab" data-bs-toggle="tab" href="#profile" role="tab"
                    aria-controls="profile" aria-selected="false">Tab 2</a>
            </li>
            <li class="nav-item" role="presentation">
                <a class="nav-link" id="contact-tab" data-bs-toggle="tab" href="#contact" role="tab"
                    aria-controls="contact" aria-selected="false">Tab 3</a>
            </li>
        </ul>
        <div class="tab-content mt-3" id="myTabContent">
            <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                <div class="row">
                    <!-- Your content for Tab 1 -->
                    <div class="col-12 col-md-4">
                        <div class="card border-0">
                            <div class="card-body py-4">
                                <h5 class="mb-2 fw-bold">To ensure that your tabs take up the full height of the page and that the content within each tab is displayed properly, you can use the following adjustments</h5>
                                <p class="mb-2 fw-bold">$72,540</p>
                                <div class="mb-0">
                                    <span class="badge text-success me-2">+9.0%</span>
                                    <span class="fw-bold">Since Last Month</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Add more cards as needed -->
                </div>
            </div>
            <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                <div class="row">
                    <!-- Your content for Tab 2 -->
                    <div class="col-12 col-md-4">
                        <div class="card border-0">
                            <div class="card-body py-4">
                                <h5 class="mb-2 fw-bold">Tab 2</h5>
                                <p class="mb-2 fw-bold">$72,540</p>
                                <div class="mb-0">
                                    <span class="badge text-success me-2">+9.0%</span>
                                    <span class="fw-bold">Since Last Month</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Add more cards as needed -->
                </div>
            </div>
            <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">
                <div class="row">
                    <!-- Video Player Section -->
                    <div class="col-12 col-md-8">
                        <div class="card border-0">
                            <div class="card-body py-4">
                                <h5 class="mb-2 fw-bold">Video Player</h5>
                                <div class="video-container mb-3">
                                    <video controls width="100%">
                                        <source src="https://youtu.be/0W3-q7rJo1U" type="video/mp4">
                                        Your browser does not support the video tag.
                                    </video>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Your existing content for Tab 3 -->
                    
                    <!-- Add more cards as needed -->
                </div>
            </div>
        </div>
    </div>
</div>
<?php include 'includes/footer.php'; ?>
